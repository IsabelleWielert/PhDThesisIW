function calculate_crosscorr(path, data, frames, f_s)

%Erzeugung und �ffnen des txt-Files 
%fid = fopen(path,'w'); 

dt = 1/f_s*1000;
df = 1/(frames*dt);
combi = [1,2;1,3;1,4;2,3;2,4;3,4];
n_lags_corr = 250;
% fprintf(fid, 'Crosscorelation for x- and y-values in different combinations\n\n');
% fprintf(fid, 'Combi        x-values      y-values\n');
 
 for i=1:size(combi,1);
 path_new = [path, 'combi_', int2str(combi(i,1)), int2str(combi(i,2)), '.mat'];      
   for j=1:2;
      [acorr(:,j),lags_acorr] = autocorr(data(:,j,combi(i,1)), n_lags_corr);
      [ccorr(:,j),lags_ccorr] = crosscorr(data(:,j,combi(i,1)), ...
          data(:,j,combi(i,2)), n_lags_corr); %       
   end
%    fprintf(fid, 'corr(B%1.0f, B%1.0f)    %1.4f      %1.4f\n', combi(i,1),...
%           combi(i,2), r(1), r(2));
 figure(i), plot(lags_acorr*dt, acorr(:,1), '*k', lags_acorr*dt, ...
     acorr(:,2), '*r'), grid on,...
     title(['Crosscorrelation for Bead ', int2str(combi(i,1)), 'and Bead ', ...
     int2str(combi(i,2))]), xlabel('time delay [ms]'), ylabel('Correlation');
   hold on
   plot(lags_ccorr(n_lags_corr+1:2*n_lags_corr+1)*dt, ...
       ccorr(n_lags_corr+1:2*n_lags_corr+1,1), '+k', lags_ccorr(n_lags_corr+1:2*n_lags_corr+1)*dt, ...
       ccorr(n_lags_corr+1:2*n_lags_corr+1,2), '+r'),...
       legend('Autocorrelation for x-values', 'Autocorrelation for y-values',...
       'Crosscorrelation for x-values', 'Crosscorrelation for y-values',...
       'Location', 'NO');
   hold off
   ccorr_save=[ccorr(n_lags_corr+1:2*n_lags_corr+1,1:2),lags_acorr];
   save(path_new, 'ccorr_save', '-mat');
 %fclose(fid);
 end

end