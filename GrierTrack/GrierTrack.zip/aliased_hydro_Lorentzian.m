function phy_power_aliased = aliased_hydro_Lorentzian(param, f_s, f)

%D is the difussion constant and f_c is the corner frequency
D = param(1);
f_c = param(2);

%R is the radius of the beads in units of �m
R = 1;
%l is the distance of the trap and the coverslip in units of �m
l = 10;
% n� is the kinematic friction coefficient of water in units of �m^2/s
nu = 1.0;
%f_n� parameterizes the flow pattern established around a sphere undergoing
%liniear oscillation in a incompressible fluid
f_nu = (10^6)*nu/(pi*R^2);
%f_m parametrizes the time it takes for friction to dissipate
f_m = 3/2*f_nu;
index_max = length(f);
n_max = 500;
phy_power_aliased(1:index_max) = 0; 
for index=1:index_max;
       
    for n=-n_max:n_max;
        %real_gamma is the real part and im_gamma is the imaginary part 
        %of the ratio gamma/gamma_0; here is gamma the Faxen's friction 
        %coefficient and gamma_0 is the stokes friction
        gamma_st = (1+(1-i)*sqrt((f(index)+n*f_s)/f_nu)-i*2/9*(f(index)+n*f_s)/f_nu);
        gamma_hydro = gamma_st*(1+9/16*R/l*(1-(1-i)/3*sqrt((f(index)+n*f_s)/f_nu)+...
            2/9*i*(f(index)+n*f_s)/f_nu-4/3*(1-exp(-(1-i)*(2*l-R)*sqrt((f(index)+...
            n*f_s)/f_nu)/R))));
        real_gamma = real(gamma_hydro);
        im_gamma = imag(gamma_hydro);

        phy_power_aliased(index) = phy_power_aliased(index) + ...
            D/(pi^2)*real_gamma/((f_c + (f(index)+n*f_s)*im_gamma - ...
            (f(index)+n*f_s)^2/f_m)^2 + ((f(index)+n*f_s)*real_gamma)^2);
    end  
end
phy_power_aliased = phy_power_aliased';
end