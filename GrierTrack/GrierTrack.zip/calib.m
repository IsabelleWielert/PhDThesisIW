function calib(handles)


%Festlegung wichtiger Konstanten zur Berechnung der Federkonstanten
k_boltzmann = 1.3806505E-23; %Boltzmannkonstante
temp = 298.15; %Temperatur im Labor
delta_T = 5; %Fehler der Temperatur
delta_x = 5; %Fehler der Positionsbestimmung in nm
delta_laser = 5;% std des Lasers in nm


PathName = handles.path;
FileName = handles.file;
bead_radius = str2double(get(handles.radius,'String'));
drift_button = get(handles.drift_on, 'Value');
angle_button = get(handles.angle_on, 'Value');
angle_step = str2double(get(handles.angular_range,'String'));
f_s = str2double(get(handles.sampl_frequ,'String'));
power_button = get(handles.power_on, 'Value');
landscape_button = get(handles.landscape_on, 'Value');
distr_button = get(handles.distr_on, 'Value');
boltzmann_button = get(handles.boltzmann_on, 'Value');
bin = str2double(get(handles.bin,'String'));
camera = get(handles.camera_input,'Value');
thres_factor = str2double(get(handles.threshold,'String'));
velocity_stokes = str2double(get(handles.velocity,'String'));
stokes_button = get(handles.stokes_button,'Value');


if (FileName == 0)
    %�ffnet Dialogfenster zur Eingabe der gew�nschten multipage_tif-Datei
    [FileName,PathName] = uigetfile('*.tif; *.bmp');
    %Falls auf Abbrechen gedr�ckt wird, soll Funktion tracking verlassen werden
    if (FileName == 0) & (PathName == 0);
      return;
    end  
end

set(handles.data_output, 'String', 'Start of Calibration');
drawnow

%Strings f�r Tif- und txt-Datei:
if (camera==1)
   FileName = strrep(FileName, '_1.tif', '');
else
   FileName = strrep(FileName, '_00001.tif', '');
end 
file_path = [PathName, FileName];
txt_file = [PathName, 'results\Kalibrierung_L', FileName, '.txt'];
tbl_file = [PathName, 'results\table_L', FileName, '.mat'];

load(tbl_file, 'pos_list_all', '-mat');
last_row = size(pos_list_all,1);
frames = pos_list_all(last_row - 2, 1);
num_input = pos_list_all(last_row - 2, 2);
diam_px = pos_list_all(last_row - 2, 3);
binning = pos_list_all(last_row - 1, 1);
m = pos_list_all(last_row-1, 2);
n = pos_list_all(last_row-1, 3);
magni = pos_list_all(last_row, 1);%binning*0.0775668;%

delta_mean_xy = sqrt(delta_x/sqrt(1000) + delta_laser^2);
delta_data_corr = sqrt(delta_x^2 + delta_mean_xy^2);

%   track-Routine
%    input:
%    1.Arg.: die zuvor generierte pos_list
%    2.Arg.: Absch�tzung der maximalen Wegl�nge in Pixel, die ein Bead
%            innerhalb eines Zeitintervalls zur�cklegt
%    output:
%    (frames*Nx4)-array:
%           1. Spalte: x-Werte
%           2. Spalte: y-Werte
%           3. Spalte: frame
%           4. Spalte: Bead
tr = track(pos_list_all(1:last_row-3,:), 4*diam_px, handles);

%frame ist 1-dim. Feld und dient sp�ter beim plotting zur Zuordnung
frame = 0 : (frames - 1);
%Erzeugung und �ffnen des txt-Files 
fid = fopen(txt_file,'w'); 
%�berschrift der txt-Datei:
fprintf(fid, 'Kalibrierung bei binning %1.0f und %4.0f frames\n\n\n', binning, frames);
fprintf(fid, 'Durchmesser der Beads ist: %3.2f�m\n', diam_px*magni);

if (angle_button==1)
  %Es sollen sp�ter die Datenpunkte der Beadzentren in Polarkoordianten
  %ausgedr�ckt werden. Daraufhin soll f�r einen bestimmten Winkelbereich
  %die msd bzw. die Federkonstante bestimmt werden. angle_step ist der Winkelbereich 
  %in Grad und angle_steps gibt die Anzahl der ben�tigten Schritte f�r einen 
  %kompletten Umlauf an. 
  angle_steps = 360/angle_step;
  %msd_angle_corr(:,:) bzw. stiffness_angle(:,:) enth�lt die msd bzw. die Federkonstante
  %f�r jeden Winkelbereich und jeden Bead  
  msd_angle_corr(1:angle_steps,1:num_input) = 0;
  stiffness_angle(1:angle_steps,1:num_input) = 0;
end


noise_corr(1:12,1) = [4.8, 4.5, 3.8, 4.0, 3.6, 3.3, 4.6, 4.3, 3.6, 3.2, 3.4, 4.0];
noise_corr(1:12,2) = [6.4, 4.2, 3.3, 6.4, 4.5, 3.5, 6.4, 4.0, 3.2, 3.5, 4.5, 6.5];
noise_corr(1:12,3) = [4.3, 3.1, 2.7, 5.9, 4.7, 3.3, 4.3, 2.9, 2.6, 3.2, 4.8, 5.7];

noise_single(1:3,1) = [3.3, 2.5, 4.1];
noise_single(1:3,2) = [5.1, 2.3, 5.6];
noise_single(1:3,3) = [4.2, 2.2, 4.7];

for i=1:num_input;
      
      subpxl = mod(tr(frames*(i-1)+1:frames*i,1:2), 0.01);
      [n_x, h_x] = hist(subpxl(:,1),round(frames/50));
      [n_y, h_y] = hist(subpxl(:,2),round(frames/50));
      h = figure('Visible', 'off');
      path_subpxl = [PathName, '\results\subpxl_bead', int2str(i), '_L', FileName, '.tif'];
      subplot(1,2,1), bar(h_x, n_x/frames), ylabel('relative frequency'), ...
         title(['Bead ',int2str(i),': Subpixel accuracy for x-values']), grid on, grid minor;
      subplot(1,2,2), bar(h_y, n_y/frames), ylabel('relative frequency'), ...
         title(['Bead ',int2str(i),': Subpixel accuracy for y-values']), grid on, grid minor;
      saveas(h, path_subpxl, 'tif')
      close(h);
    
      %data ist ein 2-dim. array das die x-Werte bzw. die y-Werte
      %des jeweiligen i.-ten Beads enth�lt 
      data =  magni*tr(frames*(i-1)+1:frames*i,1:2);
          
      %%%%%%%%%%%%%%%%%%%%%%%%%%% Driftkorrektur %%%%%%%%%%%%%%%%%%%%%%%%%%%
      %data_corr enth�lt f�r Berechnung der Abst�nde r in Polarkoordinaten bzw. f�r sp�tere Ermittlung der msd bzw.
      %Federkonstanten die relevanten Daten nach Driftkorrektur. Au�erdem
      %werden Ergebnisse in einer Graphik veranschaulicht, die abgespeichert wird 
      if (drift_button==1)
           set(handles.data_output, 'String', ['Bead ', int2str(i),'/', ...
               int2str(num_input), '. Calculation: Driftcorrection.']);
           drawnow
           path_drift = [PathName, '\results\calib_Bead', int2str(i), ...
               '_L', FileName, '.tif'];
           [slope, slope_corr, data_corr(:,1:2,i), mean_xy(i,1:2)] = ...
               driftcorrection(path_drift, i, frame, data');
      else
          mean_xy(i,1:2) = mean(data);
          
          data_corr(:,1,i) = data(:,1) - mean_xy(i,1);
          data_corr(:,2,i) = data(:,2) - mean_xy(i,2);
          
          [lin_fit, errors] = polyfit(frame, data(:,1)', 1);
          slope(1) = lin_fit(1);
          [lin_fit, errors] = polyfit(frame, data(:,2)', 1);
          slope(2) = lin_fit(1);
      end 
      
      
      if (power_button == 1)
          set(handles.data_output, 'String', ['Bead ', int2str(i),'/', ...
              int2str(num_input), '. Calculation: Power spectral density.']);
          drawnow
          [results, errors] = psd(PathName, FileName, i, ...
              data_corr(:,1:2,i), temp, handles);
      end
      
      if (stokes_button == 1)
          set(handles.data_output, 'String', ['Bead ', int2str(i),'/', ...
           int2str(num_input), '. Calculation: Shifts for Stokes calibration.']);
          drawnow
          calc_stokes_shifts(PathName, FileName, i, frame, ...
            data_corr(:,2,i)', velocity_stokes, thres_factor, bead_radius);
      end
          %data_corr(1:frames,3,i) enth�lt den Betrag r und data_corr(1:frames,4,i)
      %den Winkel phi des i-ten Beads unter Verwendung von Polarkoordinaten: x = r*cos(phi), y=r*sin(phi).
      data_corr(1:frames,3,i) = sqrt(data_corr(1:frames,1,i).^2 + data_corr(1:frames,2,i).^2);
      if (angle_button==1)
        set(handles.data_output, 'String', ['Bead ', int2str(i),'/', int2str(num_input), '. Calculation: Angle dependent stiffnesses.']);
        drawnow
        for k=1:frames
          if (data_corr(k,1,i)>0 & data_corr(k,2,i)>0)
             data_corr(k,4,i) = atand(data_corr(k,2,i)./data_corr(k,1,i));
          elseif (data_corr(k,1,i)<0 & data_corr(k,2,i)>0)    
             data_corr(k,4,i) = -atand(data_corr(k,2,i)./data_corr(k,1,i)) + 90;
          elseif (data_corr(k,1,i)<0 & data_corr(k,2,i)<0)
             data_corr(k,4,i) = atand(data_corr(k,2,i)./data_corr(k,1,i)) + 180;
          else
             data_corr(k,4,i) = atand(data_corr(k,2,i)./data_corr(k,1,i)) + 360;
          end    
        end
        
        %Bestimmung der msd_angle_corr (hier in m^2) und der Federkonstanden
        %innerhalb des definierten Winkelbereiches
        for j=1:angle_steps;
           indices = find((data_corr(1:frames,4,i) > angle_step*(j-1)) & (data_corr(1:frames,4,i) <= angle_step*j));
           sz_indices = size(indices);
           frames_angle(j) = sz_indices(1);
           if (frames_angle(j) ~= 0)
                for k=1:frames_angle(j);
                    msd_angle_data(k) = data_corr(indices(k), 3, i);
                end    
              msd_angle = (1.0E-6)^2*mean(msd_angle_data.^2);
              %Korrektur der msd_angle aufgrund der Instabilit�t des Laserfokus mit einer Standardabweichung von 8nm
              msd_angle_corr(j) = msd_angle;% - (noise_corr(j,i)*1E-9)^2;
              %Berechnung der Federkonstanten   
              stiffness_angle(j,i) = k_boltzmann*temp/msd_angle_corr(j);   
              msd_angle_data = [];
           end
        end
      end  
 %Berechnung der msd aus den x- bzw.  y-Werten und den Abst�nden r: 
 delta_x_squared(1:frames, 1:3) = 2*abs(data_corr(1:frames,1:3,i)*1E3)*delta_data_corr;
 delta_msd(1:3) = (1E-18)*mean(delta_x_squared)/sqrt(frames);
 
 for k = 1:3;
    msd(k) = (1.0E-6)^2*mean(data_corr(1:frames,k,i).^2);
 end   
    msd_corr(1) = msd(1) - (3.7*1E-9)^2;
    msd_corr(2) = msd(2) - (5.9*1E-9)^2;
    msd_corr(3) = msd(3) - sqrt((3.7*1E-9)^4 + (5.9*1E-9)^4);
 for k=1:3;   
    stiffness(k) = k_boltzmann*temp/msd_corr(k);   
    error_stiff(k) = sqrt((k_boltzmann/msd_corr(k)*delta_T)^2 + ...
        (delta_msd(k)*k_boltzmann*temp/(msd_corr(k)^2))^2);
 end
   
 % Schreiben der Daten der Kalibrierung in txt.-File
 fprintf(fid, '\nBead %1.0f (%4.2f�m/%4.2f�m):\n', i, mean_xy(i,1), mean_xy(i,2));
 fprintf(fid, 'Steigung des Drifts in x-Richtung: %+1.10f�m/frame\n', slope(1));
 fprintf(fid, 'Steigung des Drifts in y-Richtung: %+1.10f�m/frame\n', slope(2));
 if (drift_button==1)
    fprintf(fid, 'Steigung der korrigierten x-Werte: %+1.10f�m/frame\n',slope_corr(1));
    fprintf(fid, 'Steigung der korrigierten y-Werte: %+1.10f�m/frame\n\n', slope_corr(2));
 end   
 fprintf(fid, 'Standardabweichung f�r x-Werte: (%3.4f +/-%3.4f)nm\n', ...
     (1.0E9)*sqrt(msd_corr(1)), 1E9/(2*sqrt(msd_corr(1)))*delta_msd(1));
 fprintf(fid, 'Federkonstante kappa f�r x-Werte: (%1.6f+/-%1.6f)pN/nm\n', ...
     (1.0E3)*stiffness(1), (1.0E3)*error_stiff(1));
 fprintf(fid, 'Standardabweichung sigma f�r y-Werte: (%3.4f+/-%3.4f)nm\n', ...
     (1.0E9)*sqrt(msd_corr(2)), 1E9/(2*sqrt(msd_corr(2)))*delta_msd(2));
 fprintf(fid, 'Federkonstante kappa f�r y-Werte: (%1.6f+/-%1.6f)pN/nm\n\n', ...
     (1.0E3)*stiffness(2), (1.0E3)*error_stiff(2));
 fprintf(fid, 'Standardabweichung f�r Abstand r: (%3.4f+/-%3.4f)nm\n', ...
     (1.0E9)*sqrt(msd_corr(3)), 1E9/(2*sqrt(msd_corr(3)))*delta_msd(3));
 fprintf(fid, 'Federkonstante kappa: (%1.6f+/-%1.6f)pN/nm\n\n', ...
     2*(1.0E3)*stiffness(3), 2*(1.0E3)*error_stiff(3));
 if (angle_button==1)
   fprintf(fid, 'Frames pro Winkelbereich bei Gleichverteilung: %4.2f\n\n', frames/angle_steps);
   fprintf(fid, 'phi[Grad]    frames        StD[nm]    kappa[pN/nm]\n');
   for j=1:angle_steps;
      fprintf(fid, '%3.0f-%3.0f    %4.0f(%+2.1f%%)      %3.1f      %1.4f\n', (j-1)*angle_step, j*angle_step, ...
      frames_angle(j), 100*(frames_angle(j)/(frames/angle_steps)-1), (1.0E9)*sqrt(msd_angle_corr(j)), ...
      2*(1.0E3)*stiffness_angle(j,i));
   end
 end  
 if (power_button == 1)
    fprintf(fid, '\n\nResults of power spectrum analysis:\n\n');
    fprintf(fid, 'Diffusion constant D for x-values:  (%3.2e+/-%3.0e)�m�/s\n', results(2,1), errors(2,1));
    fprintf(fid, 'Diffusion constant D for y-values:  (%3.1e+/-%3.0e)�m�/s\n', results(2,2), errors(2,2));
    fprintf(fid, 'Corner frequency f_c for x-values:  (%3.1f+/-%3.1f)Hz\n', results(1,1), errors(1,1));
    fprintf(fid, 'Corner frequency f_c for y-values:  (%3.1f+/-%3.1f)Hz\n', results(1,2), errors(1,2));
    fprintf(fid, 'Stiffness of the trap for x-values:  (%1.4f+/-%1.4f)pN/nm\n', results(4,1)/1000, errors(4,1)/1000);
    fprintf(fid, 'Stiffness of the trap for y-values:  (%1.4f+/-%1.4f)pN/nm\n', results(4,2)/1000, errors(4,2)/1000);
    fprintf(fid, 'Drag coefficient of the bead for x-values:  (%3.2e+/-%3.0e)g/s\n', results(3,1), errors(3,1));
    fprintf(fid, 'Drag coefficient of the bead for y-values:  (%3.2e+/-%3.0e)g/s\n\n', results(3,2), errors(3,2));
 end    
end
fclose(fid);
% 
% path_corr = [PathName, 'results\crosscorrelation_', FileName];
% calculate_crosscorr(path_corr,data_corr, frames, f_s)
      
if (landscape_button==1)
  set(handles.data_output, 'String', 'Calculation: Potential energy landscape for angle dependent stiffnesses.');
  drawnow  
  %3D-Ausgabe der 2 dim. Potentialfunktionen
  path_land = [PathName, '\results\potential_angle_L', FileName, '.tif'];
  draw_3Dpotentials(path_land, num_input, diam_px, magni, angle_steps, angle_step, mean_xy, stiffness_angle);
end


%Berechnung der 2-dim. Verteilung aller Beadzentren
[distr, distr_xy] = calc_2Ddistribution(num_input, frames, magni, data_corr, mean_xy, m, n, bin);

if (distr_button==1)
  %Graphische Ausgabe der Distributionen
  set(handles.data_output, 'String', 'Calculation: probability distributions.');
  drawnow
  
  for i=1:num_input;
     
    draw_2Ddistribution(PathName, FileName, distr, distr_xy, frames, bin, mean_xy, magni, diam_px, i);
  end
end

if (boltzmann_button==1)
  set(handles.data_output, 'String', 'Calculation: Boltzmann distribution based on probability distribution.');
  drawnow
  %Berechnung des Potentials �ber Boltzmann-Verteilung:
  %Potential ist proportional zum wahren Potential U(x)=-k_b*T*exp(P(x)), wobei P(x) die Wahrschinlichkeit darstellt
  %den Bead am Ort x anzutreffen. Einheit: pN*�m
  potential = -(1.0E18)*k_boltzmann*temp*log((distr + 1)/frames);

  %Graphische Ausgabe der Boltzmann-Verteilungen
  for i=1:num_input;
     path_boltz = [PathName, '\results\potential_bead', int2str(i),'_L', FileName, '.tif']; 
     draw_3Dboltzmann(path_boltz, potential, bin, mean_xy, magni, diam_px,i);
  end   
end

set(handles.data_output, 'String', 'End of Calibration!');
drawnow

end