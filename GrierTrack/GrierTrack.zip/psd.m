function [results, errors] = psd(PathName, FileName, z, data, temp, handles)
   
%global data_psd
   k_B = 1.38065E-23;
   path_psd_loglog = [PathName, '\results\psd_loglog_Bead', int2str(z), ...
       '_L', FileName, '.tif'];
   path_psd_x =  [PathName, '\results\psd_x_linear_Bead', int2str(z), ...
       '_L', FileName, '.tif'];
   path_psd_y =  [PathName, '\results\psd_y_linear_Bead', int2str(z), ...
       '_L', FileName, '.tif'];
   
   %window = 'bartlett';
   nfft = size(data,1);
   n_psd = nfft/2 + 1;
   
   %psd_values defines the number of values of the periodogram estimate in
   %the range of 0 to f_nyq.
   
   f_s = str2double(get(handles.sampl_frequ,'String'));
   f_min = str2double(get(handles.f_min,'String'));
   f_max = str2double(get(handles.f_max,'String'));
   n_b = str2double(get(handles.n_b,'String'));
   f_nyq = f_s/2;
   T_msr = (1/f_s)*size(data,1);
   
   % Hs is a sectrum-object for estimating a periodogram with a
   % 'bartlett'-window
   Hs = spectrum.periodogram;%spectrum.welch(window, seg_length, overlap, 'UserDefined');
   
   
   %the function psd() below calculate the psd defined from 0 to f_nyq and
   %its integral is the mean squared amplitude of the dataseries 
   Hpsd_x = psd(Hs, data(:,1), 'Fs', f_s, 'NFFT', nfft, 'SpectrumType', 'onesided');
   Hpsd_y = psd(Hs, data(:,2), 'Fs', f_s, 'NFFT', nfft, 'SpectrumType', 'onesided');
   
  % path_noise = ['C:\Documents and Settings\Rainer\My Documents\Experiment\Calib\STD_LASER_Phantom\noi_triangle\results\power_spectrum_Bead', int2str(i),'_Lnoi_triangle.mat'];
  % load(path_noise, 'data_noise', '-mat');
   
   psd_xy(:,1) = Hpsd_x.Data;% - data_noise(:,1);
   psd_xy(:,2) = Hpsd_y.Data;% - data_noise(:,1);
   f = Hpsd_x.Frequencies';
   
   figure(z+13), plot(f, psd_xy(:,1), '-k', f, psd_xy(:,2), '-r');
   %only for power spectra of noise
%        data_noise = psd_xy;
%         data_noise(:,3) = f;
%         path_noise = strrep(path, '.tif', '.mat');
%        save(path_noise, 'data_noise', '-mat');
   
   %Buildung up of psd-frequency-blocks with n_b in length in order to reduce noise
   
   b_max = ceil(n_psd/n_b);
   if (n_b~=1)
      set(handles.data_output, 'String', ['Number of blocks: ', int2str(b_max)]);
      drawnow
     n_b_last = n_psd - (b_max-1)*n_b;    
     f_bar(1:b_max) = 0;
     psd_xy_bar(1:b_max,1:2) = 0;
     if (n_b_last~=0)
         b_max = b_max - 1;
     end
     for i=1:b_max;
         for j=1:n_b;
             f_bar(i) = f_bar(i) + f(n_b*(i-1)+j);
             psd_xy_bar(i,:) = psd_xy_bar(i,:) + psd_xy(n_b*(i-1)+j,:);
         end    
     end
     f_bar = 1/n_b*f_bar;
     psd_xy_bar =1/n_b*psd_xy_bar;
     for j=1:n_b_last;
         f_bar(b_max+1) = f_bar(b_max+1) + f(n_b*b_max+j);
         psd_xy_bar(b_max+1,:) = psd_xy_bar(b_max+1,:) + psd_xy(n_b*b_max+j,:);
     end
     
%      folgende kommentierte Zeilen geh�ren zur Mittelung von mehreren powerspektren
%      path_data = [PathName, '\results\power_spectrum_Bead', int2str(3), '_L', FileName, '.mat'];
%      load(path_data, 'data_psd', '-mat');
%      psd_xy_bar = data_psd(:,:,z);
%      data_psd(:,:,z) = psd_xy_bar; 
%      if (z==3)
%         path_data = strrep(path, '.tif', '.mat');
%         save(path_data, 'data_psd', '-mat');
%      end
     
     if (n_b_last~=0)
        b_max = b_max + 1; 
        f_bar(b_max) = 1/n_b_last*f_bar(b_max);
        psd_xy_bar(b_max,:) =1/n_b_last*psd_xy_bar(b_max,:);
     end 
    
     f_plot = 10.^(0:log10(f_nyq)/b_max:log10(f_nyq));
     f_plot_new = zeros(1,b_max);
     for i=1:b_max
         f_plot_new(i) = (f_plot(i)+f_plot(i+1))/2;
     end
   
     f_plot = f_plot_new;
     f_bar_plot(1:b_max-1) = 0;
     psd_xy_bar_plot(1:b_max-1, 1:2) = 0;
     n_b_plot = zeros(1, b_max - 1);
     n_b_plot_prior = 0;
     for i=1:b_max-1;
        indices = find(f>=f_plot(i) & f<f_plot(i+1));
        n_b_plot(i) = size(indices,2);
        for j=1:n_b_plot(i);
             f_bar_plot(i) = f_bar_plot(i) + f(n_b_plot_prior+j);
             psd_xy_bar_plot(i,:) = psd_xy_bar_plot(i,:) + psd_xy(n_b_plot_prior+j,:);
        end
        if (n_b_plot(i) ~= 0)
            f_bar_plot(i) = 1/n_b_plot(i)*f_bar_plot(i);
            psd_xy_bar_plot(i,:) = 1/n_b_plot(i)*psd_xy_bar_plot(i,:);
        else
            f_bar_plot(i) = 0;
            psd_xy_bar_plot(i,:) = 0;
        end    
      
        n_b_plot_prior = n_b_plot_prior + n_b_plot(i);
     end
   end   
   
   psd_x_bar_plot = psd_xy_bar_plot(:,1)';
   psd_y_bar_plot = psd_xy_bar_plot(:,2)';
   %Bounds for graphical output in loglog plot
   low_b_log = ceil((b_max-1)/log10(f_nyq)*log10(f_min));
   up_b_log = ceil((b_max-1)/log10(f_nyq)*log10(f_max));
   %Fitting only in the range of f_min - f_max.
   lower_bound = ceil(b_max/f_nyq*f_min);
   upper_bound = ceil(b_max/f_nyq*f_max);
   if (n_b ~= 1)
      f_fit = f_bar(lower_bound:upper_bound); 
   else 
      f_fit = f(lower_bound:upper_bound);
   end
       
   %D0 is in units of �m^2/s and fc0 is in units of Hz.
   D0 = 0.5;
   f_c0 = 150;
   
   my_lorentzian = fittype('aliased_Lorentzian([D,f_c], f_s, x)', ...
       'coeff', {'D', 'f_c'}, 'problem', 'f_s');
   opts = fitoptions(my_lorentzian);
   set(opts,'TolFun',1E-38, 'TolX', 1E-20, 'StartPoint', [D0, ...
       f_c0], 'Lower', [0.001, 1], ...
       'Upper', [100, 1000]);
   
   
   %preallocating of arrays used in for-loop below
   D_xy = zeros(1,2);
   f_c_xy = zeros(1,2);
   gamma_0_xy = zeros(1,2);
   stiffness_power_xy = zeros(1,2);

   if (n_b ~= 1)
       psd_fit_xy = psd_xy_bar(lower_bound:upper_bound,1:2);
   else
       psd_fit_xy = psd_xy(lower_bound:upper_bound,1:2);
   end    
   [fit_x, gof_x, out_x] = fit(f_fit', psd_fit_xy(:,1), my_lorentzian, opts, ...
       'problem', f_s);       
   [fit_y, gof_y, out_y] = fit(f_fit', psd_fit_xy(:,2), my_lorentzian, opts, ...
       'problem', f_s);   
   
   D_xy = [fit_x.D, fit_y.D];
   f_c_xy = [fit_x.f_c, fit_y.f_c];
   
   
   confi_x = confint(fit_x, 0.68);
   confi_y = confint(fit_y, 0.68);
   
   c_x = predint(fit_x, f_fit', 0.95); 
   c_y = predint(fit_y, f_fit', 0.95);
   
   max_x_res = max(out_x.residuals);
   max_y_res = max(out_y.residuals); 

   for k=1:2;
       %Calculation of errors for D and f_c
       s_fc = sqrt(pi/(fun_u(f_min/f_c_xy(k), f_max/f_c_xy(k))-fun_v...
           (f_min/f_c_xy(k), f_max/f_c_xy(k))));
       s_D = sqrt(fun_u(f_min/f_c_xy(k), f_max/f_c_xy(k))/((1+pi/2)*...
           (f_max/f_c_xy(k)-f_min/f_c_xy(k))))*s_fc;
       u_fc(k) = s_fc/sqrt(pi*f_c_xy(k)*T_msr)*f_c_xy(k);
       u_D(k) = sqrt((1+pi/2)/(pi*f_c_xy(k)*T_msr))*s_D*D_xy(k);
       %Calculation of drag coefficients in units of g/s 
       gamma_0_xy(k) = (1E15)*k_B*temp/D_xy(k);
       u_gamma(k) = gamma_0_xy(k)*u_D(k)/D_xy(k);
       %Calculation of stiffnesses for x- and y-values
       stiffness_power_xy(k) = (1E3)*2*pi*f_c_xy(k)*gamma_0_xy(k);
       u_stiffness(k) = stiffness_power_xy(k)*sqrt((u_fc(k)/f_c_xy(k))^2 + ...
           (u_gamma(k)/gamma_0_xy(k))^2);
   end
   
   error_D_x = confi_x(2,1) - confi_x(1,1);
   error_D_y = confi_y(2,1) - confi_y(1,1);
   error_fc_x = confi_x(2,2) - confi_x(1,2);
   error_fc_y = confi_y(2,2) - confi_y(1,2);
   error_gamma_x = gamma_0_xy(1)*error_D_x/D_xy(1);
   error_gamma_y = gamma_0_xy(2)*error_D_x/D_xy(2);
   error_stiff_x = stiffness_power_xy(1)*sqrt((error_fc_x/f_c_xy(1))^2 + ...
           (error_gamma_x/gamma_0_xy(1))^2);
   error_stiff_y = stiffness_power_xy(2)*sqrt((error_fc_x/f_c_xy(2))^2 + ...
           (error_gamma_x/gamma_0_xy(2))^2);
   
   h = figure('Visible', 'on');
    subplot(2,1,1), errorbar(f_fit, psd_fit_xy(:,1)', ...
             1/2*aliased_Lorentzian([fit_x.D, ...
             fit_x.f_c], f_s ,f_fit)'/sqrt(n_b), '.r'), ...
             ylabel('power spectrum [�m^2s]','FontSize',12), ...
             xlabel('frequency [Hz]','FontSize',12), title(['Bead ',int2str(z),...
             ': Power spetral density for x-values'],'FontSize',12), ...
             axis([min(f_fit) max(f_fit) min(psd_fit_xy(:,1)) max(psd_fit_xy(:,1))]);%,...
    hold on
    plot(f_min:1:f_max, aliased_Lorentzian([fit_x.D,...
      fit_x.f_c], f_s, f_min:1:f_max)', '-r');
    hold on
    plot(f_fit, c_x, '--r'), legend('exp. data (blocked)', 'fit', ...
        'prediction bounds (95%)', 'Location', 'NE');
    hold off

    subplot(2,1,2), bar(f_fit, out_x.residuals, 'r'), ylabel('Residuals','FontSize',12), ...
             xlabel('frequency [Hz]','FontSize',12), title(['Bead ',int2str(z),...
             ': Distribution of residuals for x-values'],'FontSize',12), ...
             axis([min(f_fit) max(f_fit) -max_x_res max_x_res]),...
             legend('residuals', 'Location', 'NE'),...
             text(min(f_fit)+20, max_x_res - 2*max_x_res/10,['adjusted R^2 =', ...
             num2str(gof_x.adjrsquare, '%1.5f')],'BackgroundColor',...
             [1 1 1],'FontSize',10);%

   saveas(h, path_psd_x, 'tif');
   %close(h);

   h = figure('Visible', 'on');
    subplot(2,1,1), errorbar(f_fit, psd_fit_xy(:,2)', ...
             1/2*aliased_Lorentzian([fit_y.D, ...
             fit_y.f_c], f_s ,f_fit)'/sqrt(n_b), '.r'), ... 
             ylabel('power spectrum [�m^2s]','FontSize',12), ...
             xlabel('frequency [Hz]','FontSize',12), title(['Bead ',int2str(z),...
             ': Power spetral density for y-values'],'FontSize',12), ...
             axis([min(f_fit) max(f_fit) min(psd_fit_xy(:,2)) max(psd_fit_xy(:,2))]);%,...

    hold on
    plot(f_min:1:f_max, aliased_Lorentzian([fit_y.D,...
      fit_y.f_c], f_s, f_min:1:f_max)', '-r');
    hold on
    plot(f_fit, c_y, '--r'), legend('exp. data (blocked)', 'fit', ...
        'prediction bounds (95%)', 'Location', 'NE');
    hold off

    subplot(2,1,2), bar(f_fit, out_y.residuals, 'r'), ylabel('Residuals','FontSize',12), ...
             xlabel('frequency [Hz]','FontSize',10), title(['Bead ',int2str(z),...
             ': Distribution of residuals for y-values'],'FontSize',12), ...
             axis([min(f_fit) max(f_fit) -max_y_res max_y_res]),...
             legend('residuals', 'Location', 'NE'),...
             text(min(f_fit)+ 20, max_y_res - 2*max_y_res/10,['adjusted R^2 =', ...
             num2str(gof_y.adjrsquare, '%1.5f')],'BackgroundColor',...
             [1 1 1],'FontSize',12);%

   saveas(h, path_psd_y, 'tif');
   %close(h);
   
   h = figure('Visible', 'on');    
   
   subplot(2,1,1),  errorbarloglog(f_bar_plot(low_b_log:up_b_log),...
      psd_x_bar_plot(low_b_log:up_b_log), psd_x_bar_plot(...
      low_b_log:up_b_log) - aliased_Lorentzian([fit_x.D, ...
      fit_x.f_c], f_s ,f_bar_plot(low_b_log:up_b_log))'...
      ./sqrt(n_b_plot(low_b_log:up_b_log)), ...
      psd_x_bar_plot(low_b_log:up_b_log) + aliased_Lorentzian(...
      [fit_x.D, fit_x.f_c], f_s, f_bar_plot(...
      low_b_log:up_b_log))'./sqrt(n_b_plot(low_b_log:up_b_log)),...
      'none', '.', 'r'), 
  xlabel('frequency [Hz]','FontSize',10), ylabel('power [�m�s]','FontSize',10),...
      title(['Bead ' ,int2str(z),': Power spectral density for x-values'],'FontSize',12), ...
  axis([f_min f_max min(psd_x_bar_plot(low_b_log:up_b_log))...
  max(psd_x_bar_plot(low_b_log:up_b_log))]), grid on, grid minor,...
  text(max(f_fit)-1000, max(psd_x_bar_plot(low_b_log:up_b_log)) - ...
      1/2*max(psd_x_bar_plot(low_b_log:up_b_log)) ,...
     ['Results: \newline D = ', num2str(fit_x.D, '(%1.2e'), '\pm',...
     num2str(error_D_x, '%1.2e)�m^2/s'), '\newline f_c = ',...
     num2str(fit_x.f_c, '(%3.0f'), '\pm', num2str(error_fc_x, ...
     '%3.0f)Hz'), '\newline \gamma = ',...
     num2str(gamma_0_xy(1), '(%1.2e'), '\pm', num2str(error_gamma_x, ...
     '%1.2e)g/s'), '\newline \kappa = ',...
     num2str(stiffness_power_xy(1)/1000, '(%1.4f'), '\pm',...
     num2str(error_stiff_x/1000, ...
     '%1.4f)pN/nm')], 'BackgroundColor', 'r', 'FontSize',9);%
  hold on
  loglog(f_min:1:f_max, aliased_Lorentzian([fit_x.D,...
      fit_x.f_c], f_s, f_min:1:f_max), 'r');
  hold off
  
  subplot(2,1,2), errorbarloglog(f_bar_plot(low_b_log:up_b_log),...
      psd_y_bar_plot(low_b_log:up_b_log) , psd_y_bar_plot(...
      low_b_log:up_b_log) - aliased_Lorentzian([fit_y.D, ...
      fit_y.f_c], f_s ,f_bar_plot(low_b_log:up_b_log))'...
      ./sqrt(n_b_plot(low_b_log:up_b_log)), ...
      psd_y_bar_plot(low_b_log:up_b_log) + aliased_Lorentzian(...
      [fit_y.D, fit_y.f_c], f_s, f_bar_plot(...
      low_b_log:up_b_log))'./sqrt(n_b_plot(low_b_log:up_b_log)),...
      'none', '.', 'r'), 
  xlabel('frequency [Hz]','FontSize',10), ylabel('power [�m�s]','FontSize',10), ...
      title(['Bead ' ,int2str(z),': Power spectral density for y-values'],'FontSize',12), ...
  axis([f_min f_max min(psd_y_bar_plot(low_b_log:up_b_log)) ...
  max(psd_y_bar_plot(low_b_log:up_b_log))]), grid on, grid minor,...
  text(max(f_fit)-1000, max(psd_y_bar_plot(low_b_log:up_b_log)) - ...
      1/2*max(psd_y_bar_plot(low_b_log:up_b_log)) ,...
     ['Results: \newline D = ', num2str(fit_y.D, '(%1.2e'), '\pm',...
     num2str(error_D_y, '%1.2e)�m^2/s'), '\newline f_c = ',...
     num2str(fit_y.f_c, '(%3.0f'), '\pm', num2str(error_fc_y, ...
     '%3.0f)Hz'), '\newline \gamma = ',...
     num2str(gamma_0_xy(2), '(%1.2e'), '\pm', num2str(error_gamma_y, ...
     '%1.2e)g/s'), '\newline \kappa = ',...
     num2str(stiffness_power_xy(2)/1000, '(%1.4f'), '\pm',...
     num2str(error_stiff_y/1000, ...
     '%1.4f)pN/nm')], 'BackgroundColor', 'r', 'FontSize',9);%
  hold on
  loglog(f_min:1:f_max, aliased_Lorentzian([fit_y.D,...
      fit_y.f_c], f_s, f_min:1:f_max), 'r');
  hold off
  
  saveas(h, path_psd_loglog, 'tif')
  %close(h);

  
results = [f_c_xy; D_xy; gamma_0_xy; stiffness_power_xy];
errors = [u_fc; u_D; u_gamma; u_stiffness];
   
end

function [u] = fun_u(x_1, x_2)
  u = 2*x_2/(1+x_2^2)-2*x_1/(1+x_1^2)+2*atan((x_2-x_1)/(1+x_1*x_2));
end

function [v] = fun_v(x_1, x_2)
  v = 4/(x_2-x_1)*atan((x_2-x_1)/(1+x_1*x_2))^2;
end  


