function deletion(camera,start,stop)

%�ffnet Dialogfenster zur Eingabe der gew�nschten multipage_tif-Datei
[FileName,PathName] = uigetfile('*.tif');
%Falls auf Abbrechen gedr�ckt wird, soll Funktion tracking verlassen werden
if (FileName == 0) & (PathName == 0);
    return;
end  

% Strings f�r Dateinamen
if (camera==1)
   FileName = strrep(FileName, '_1.tif', '');
else
   FileName = strrep(FileName, '_00001.tif', '');
end 

file_path = [PathName, FileName];

  for k=start:stop
        if(mod(k,100)==0);
           disp(['frame ', int2str(k), ' is deleted']); 
        end
        if (camera==1)
              num = int2str(k);
        else
              num = num2str(k, '%05.0f');
        end 
       delete([file_path, '_', num, '.tif']); 
  end 
    
end
