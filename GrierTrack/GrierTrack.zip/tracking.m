%*****************************************************************************************
%This function "tracking" is designed for a holgraphic optical tweezers
%setup for calibration methods. It calculates the centers of a desired
%number of trapped beads from aa simple tiff-image. 
%
%input:
%      frames_input - Anzahl der Bilder der multipage_tif-Datei
%      num_input - Anzahl der Beads, die getrackt werden sollen
%optional input:
%      cutting_range - Anzahl der herausgeschnittenen frames, wenn ein fehlerhafter frame
%                      auftaucht. Wenn also die durch num_input vorgegebenen
%                      Beads nicht gefunden werden, so gehen im Bereich von
%                      [frame - floor(cutting_range/2), frame + floor(cutting_range/2)]
%                      nicht ins tracking ein; preset: cutting_range = 7 
%      diameter      - Diameter of the Beads in Pixel, preset: diameter = 33
%      binning       - Binning of the frames (1 - 4)
%      magni_input   - magnification of the objective (50, 60, 100); preset magni = 60
%
% Zum Tracken werden Routinen der Griergroup verwendet (bpass, pkfind, cntrd, track).
% bpass filtert das einzelne Bild; pkfind gibt die vorl�ufigen Koordinaten der
% gefundenen Beads zur�ck; cntrd berechnet Zentrum der Beads mit subpixel
% Genauigkeit. Daraufhin wird mit track ein Datenfeld tr erzeugt, dessen 
% Inhalt folgende Bedeutung hat:
% Spalte   Bedeutung
%   1      x-Koordinate des jeweiligen Beads
%   2      y-Koordinate des jeweiligen Beads
%   3      frame des jeweiligen Beads
%   4      Numer des Beads
%
%output:
%       n tif-files: F�r n getrackte Beads werden n Graphen gespeichert, die jeweils
%                      frame gegen x- bzw. y-Werte darstellen ohne und mit
%                      Driftkorrektur.
%       txt-file: Enth�lt Koordinaten der Beads, Steigung des Drifts bzw. nach Drift- 
%                 korrektur, Standardabweichung und Federkonstante f�r jeden 
%                 Bead und f�r x-Koordinaten und y-Koordinaten
%
%       Ausgegebene Dateien werden in Ordner der multipage_tif-Datei
%       gespeichert!!
%******************************************************************************************
function [FileName, PathName] = tracking(handles, cutting_range)


global pos_list_all

frames_input = str2double(get(handles.frames_input,'String'));
binning = str2double(get(handles.binning_input,'String'));
if (binning <= 0) | (binning > 4)
    errordlg('Binning is out of range (1 - 4)!!');
    return;    
end 
camera = get(handles.camera_input,'Value');
num_input = str2double(get(handles.num_input,'String'));
diameter = str2double(get(handles.diameter_input,'String'));
if (diameter < 5) | (diameter > 35)
    errordlg('Diameter of the Beads is out of range (5 - 35)');
    return;
elseif (diameter/2 == floor(diameter/2))
    diameter = round(diameter/2)*2 + 1;    
    warndlg('Diameter has to be an odd valued integer.\n The program adds one');
end

%Berechnung des tats�chlichen Durchmessers der Beads aufgrund von binning
diam_px = round(diameter/binning);
if (diam_px/2 == floor(diam_px/2))
      diam_px = diam_px + 1;
end

%Festlegung von der Bandpass-Grenze:
pass_limit = diam_px + 2;
%�ffnet Dialogfenster zur Eingabe der gew�nschten tif oder bmp Datei
[FileName,PathName] = uigetfile('*.tif; *.bmp');
%Falls auf Abbrechen gedr�ckt wird, soll Funktion tracking verlassen werden
if (FileName == 0) & (PathName == 0);
    return;
end  

% Festlegung wichtiger Konstanten zur Berechnung der Federkonstanten
switch camera
    case 1 %60x Wasser Immersionsobjektiv (Retiga)
        magni = binning*0.0398532;
    case 2 %60x Wasser Immersionsobjektiv (Phantom)
        magni = binning*0.134196;%0.0775668; 
end        
k_boltzmann = 1.3806505E-23; %Boltzmannkonstante
temp = 293.15; %Temperatur im Labor


% Strings f�r Dateinamen
if (camera==1)
   FileName = strrep(FileName, '_1.tif', '');
else
   FileName = strrep(FileName, '_00001.tif', '');
end 

file_path = [PathName, FileName];
tbl_file = [PathName, 'results\table_L', FileName, '.mat'];
if (isdir([PathName, 'results'])==0)
    mkdir([PathName, 'results']);
end    
% Erstelle Ordner f�r Tif-Dateien (getrackte Beads mit Beadzentren)
if (isdir([PathName, 'pics_trackedbeads'])==0)
   mkdir([PathName, 'pics_trackedbeads']);
end   


frames = frames_input;
num_beads = num_input;
%count z�hlt die frames die beim tracking aufgrund fehlerhafter frames
%herausgeschnitten werden
count = 0;
%i ist die Laufvariable f�r folgende while-Schleife und markiert
%den ausgewerteten frame
i = 1;
k = 1;
%noise ist ein Parameter der bpass Routine
noise = 1;
pos_list = 0;
pos=1;
l_pos_list = num_input*1000;
pos_list_all = [];
%Folgende while-Schleife liest Bilder aus, findet Beads und speichert Daten
%(x-Wert, y-Wert, frame) am Ende aus jedem Bild in ein einziges Array 'pos_list'.
%Zus�tzlich soll, falls die gefundene Anzahl an Beads "num_beads" gr��er 
%(bzw. kleiner) als "num_input" ist, der Bandpass sukzessiv erh�ht
%(bzw. erniedrigt) werden. Jedesmal wird die Routine pkfnd die Anzahl der gefundenen 
%Beads bestimmen. Dadurch wird pass_limit so eingestellt, dass
%num_beads=num_input ist. Bewegt sich pass_limit aus den zugelassen Bereich (1-50), 
%da z.B. der frame fehlerhaft ist (z.B. keine Beads) so wird innerhalb dieser while-Schleife 
%dieser frame und die frames in der Umgebung (insgesamt cutting_range
%frames) aus der pos_list herausgenommen. Zur Kontrolle von pkfnd und cnt
%wird in fig(1) der erste frame mit getrackten Koordinaten ausgegeben. Hier
%kann �berpr�ft werden, ob das Zentrum der Beads gefunden wird. Falls ein
%fehlerhafter frame auftritt, wird dieser auch jedesmal ausgegeben, damit
%sich leichter ein Grund finden l��t.
set(handles.data_output, 'String', 'Tracking starts with frame 1!');
drawnow
while(i <= frames_input)  
  if (camera==1)
      num = int2str(i);
      %in 'img' wird das erste Bild geladen (s. "help" f�r unterst�tzte Formate und Bildtiefen)  
      img = double(imread([file_path, '_',num , '.tif']));  
  else
      num = num2str(i, '%05.0f');
      %in 'img' wird das erste Bild geladen (s. "help" f�r unterst�tzte Formate und Bildtiefen)  
      img = double(imread([file_path, '_',num , '.tif']));  
  end
  
  % bpass-Routine
  %    input:
  %    1.Arg.: Geladenen Bild (->2-dim. Array)
  %    2.Arg.: L�nge in Pixeln �ber die Rauschen gemittelt werden soll
  %    3.Arg.: Bandpass-Grenze in Pixeln (ungerader Wert); sollte gr��er als ein typisches Objekt sein 
  %    output:
  %    Gefiltertes Bild (-> 2-dim. array) 
  %Filterung des Bildes
  img_filter = bpass(img, noise, pass_limit);
  %jetzt wird in max_bright h�chste Intensit�t (zw. 0-255) des Bildes
  %img_filter berechnet
  max_bright = max(max(img_filter)); 
  %und daraus berechnet sich der Schwellenwert 'thrh' f�r die Routine pkfnd
  thrh =  2/3*max_bright;
  % pkfnd-Routine:
  %   inputs:
  %   1.Arg.: Das (gefilterte) Bild in dem Helligkeitsspeaks gefunden werden sollen
  %   2.Arg.: Der kleinste Helligkeitswert, der noch als lokales Maximum
  %           druchgehen soll
  %   3.Arg.(optional): Wenn die Daten des Bildes verrauscht sind, d.h. das
  %                     pro Teilchen, das getrackt werden soll, mehrere
  %                     lokale Maxima vorliegen, soll hellster Wert
  %                     genommen werden. Wert sollte etwas gr��er als
  %                     Teilchendurchmesser in Pixeln sein
  %   output:
  %   (Nx2)-array, dass in [:,1] die x-Werte der lokalen Maxima enth�lt und
  %   in [:,2] die zugeh�rigen y-Werte
  pk = pkfnd(img_filter, thrh, pass_limit);
  %Die Routine cntrd berechnet das genaue Zentrum eines jeden gefundenen
  %Beads der Routine pkfnd
  %  cntrd-Routine
  %    inputs:
  %    1.Arg.: Das gefilterte Bild
  %    2.Arg.: output der pkfnd-Routine
  %    3.Arg.: Dieser Wert entspricht der Gr��e der zu verfolgenden Beads in Pixeln
  %            plus 2 und gibt den Bereich an �ber den bei der Kalkulation des
  %            Zentrums eines jeden Beads gemittelt werden soll.
  %    output:
  %    (Nx4)-Array, dass f�r n getrackte Beads x-, y-, Helligkeitswerte und
  %    Radius gespeichert hat
  cnt = cntrd(img_filter, pk, diam_px+2);
  num_beads = size(cnt,1); %Anzahl der getrackten Beads    
  %Folgende while-Schleife erh�ht pass_limit um 2 solange die Anzahl der
  %gefunden Beads num_beads gr��er als Eingabe num_input ist
  while (num_beads > num_input)
      thrh = thrh + max_bright/10;
      if (thrh >= max_bright)
          set(handles.data_output, 'String',['frame: ', int2str(i), '; Number of beads (', int2str(num_beads), ') found is not equal to input -> frame will be deleted']);
          drawnow
          break;
      end    
      
      pk = pkfnd(img_filter, thrh, pass_limit);
      cnt = cntrd(img_filter, pk, diam_px+2);
      num_beads = size(cnt,1);
  end
  %Folgende while-Schleife erniedrigt pass_limit um 2 solange die Anzahl der
  %gefunden Beads num_beads kleiner als Eingabe num_input ist
  while (num_beads < num_input)
      thrh = thrh - max_bright/10;
      if (thrh <= 1)
          set(handles.data_output, 'String',['frame: ', int2str(i), '; Number of beads (', int2str(num_beads), ') found is not equal to input -> frame will be deleted']);
          drawnow
          break;
      end    
      pk = pkfnd(img_filter, thrh, pass_limit);
      cnt = cntrd(img_filter, pk, diam_px+2);
      num_beads = size(cnt,1);
  end
  
  %Falls trotz der vorhergehenden while-Schleifen die Anzahl der getrackten
  %Beads num_beads nicht mit num_input �bereinstimmen, sollen frames um
  %i.ten fehlerhaften frame im Ausma� von cutting_range herausgeschnitten
  %werden
  if (num_beads ~= num_input)
      %Da um den fehlerhaften frame herum geschnitten werden soll, m�ssen
      %zwischen den F�llen i<cutting_range und i>cutting_range
      %unterschieden werden
      if (i >= cutting_range)
          %find_frame stellt 1-dim. array dar, dass die frame-Nummern
          %enth�lt, die herausgeschnitten werden
          find_frame(count + 1:count + cutting_range) = (i-floor(cutting_range/2)):(i+floor(cutting_range/2));
          %Es soll danach erst bei frame i + cutting_range weiter getrackt werden 
          i = i + cutting_range;
      else
          find_frame(1:cutting_range) = 1:cutting_range;
          i = cutting_range + 1;
      end
      frames = frames - cutting_range;%Zahl der tats�chlich verwendeten frames
      count = count + cutting_range;%Zahl der herausgeschnittenen frames    
      thrh =  max_bright/2;%thrh wird wieder zur�ck auf Ausgangswert gesetzt 
      continue;
  end
  if(mod(i,100)==0);
    set(handles.data_output, 'String',['frame: ', int2str(i), '; threshold: ', num2str(thrh, '%3.2f'), '; bandpass Max.: ', int2str(pass_limit)]);
    drawnow
    
    path_pics = [PathName, 'pics_trackedbeads\', FileName, '_', int2str(i) ,'.tif'];
    h = figure('Visible', 'off');
    colormap('gray'), imagesc(img_filter);
      hold on
      plot(cnt(:,1), cnt(:,2), '+r');
      hold off
    saveas(h, path_pics, 'tif');
    close(h);
  end
  %Erster frame soll immer falls nicht dieser schon fehlerhaft ist
  %ausgegeben werden
  if (i == 1);
      %Bestimmung der Gr��e der Bilder f�r sp�tere 2-dim.
      %Potentialdarstellung
      [m,n] = size(img);
  end
  
  %speichern der Koordinaten in der Positionsliste pos_list
  for j=1:num_input
     if (mod(pos, l_pos_list) == 0)  
        %Falls �berhauft keine Ergebnisse in der pos_list erzielt wurden, 
        %soll abgebrochen werden:
        if (pos_list == 0)
            warndlg(['No results in frame', int2str(i-l_pos_list), ' - ', int2str(i), '!\n Check your parameters (e.g. number of beads)!!']);
            return;
        end 
        k = k+1;
        pos_list_all = vertcat(pos_list_all, pos_list);
        pos_list = 0;
     end 
     pos = num_input*(i - count - 1) + j - l_pos_list*(k-1); 
     pos_list(pos,1:3) = [cnt(j,1:2), i - count];
  end
  i = i + 1;   
end
pos_list_all = vertcat(pos_list_all, pos_list);

%   track-Routine
%    input:
%    1.Arg.: die zuvor generierte pos_list
%    2.Arg.: Absch�tzung der maximalen Wegl�nge in Pixel, die ein Bead
%            innerhalb eines Zeitintervalls zur�cklegt
%    output:
%    (frames*Nx4)-array:
%           1. Spalte: x-Werte
%           2. Spalte: y-Werte
%           3. Spalte: frame
%           4. Spalte: Bead
data_track = [frames, num_input, diam_px; binning, m, n; magni, 0, 0];
pos_list_all = vertcat(pos_list_all, data_track); 
save(tbl_file, 'pos_list_all', '-mat');
if (frames < frames_input)
   set(handles.data_output, 'String', ['End of Tracking! Only ', int2str(frames), ' frames were used']);
   drawnow
   fprintf(1, 'The following frames had to be deleted:\n');
   disp(find_frame);
else
   set(handles.data_output, 'String', 'End of Tracking! All frames were used!');
   drawnow
end


button = questdlg('Do you want to delete all tif-files?','Deletion of pictures', 'Yes', 'No', 'Yes');

if (button=='Yes')
    for k=2:frames_input
        if(mod(k,100)==0);
           set(handles.data_output, 'String',['frame ', int2str(k), ' is deleted']);
           drawnow 
        end
        if (camera==1)
              num = int2str(k);
              delete([file_path, '_', num, '.tif']); 
        else
              num = num2str(k, '%05.0f');
              delete([file_path, '_', num, '.tif']); 
        end 
    end 
elseif (button =='No')
    
end    


end
 




