function [y] = gaussian(param, x)
    k_b = 1.3806505E-23; %Boltzmann constant
    T = 298.15; %temperature in the lab in units of Kelvin
    N = param(1);
    kappa = param(2)*1000;
    mu = param(3);
    
    y = N*exp(-1/2*(1E-18)*kappa*(x-mu).^2./(k_b*T));
    
end