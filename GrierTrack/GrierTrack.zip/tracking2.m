%*****************************************************************************************
%Dieses Programm trackt Beads (gefangen in HOT) beliebiger Zahl aber definierten Gr��e
%in einem multipage_tif-file beliebiger frame-Zahl.
%
%input:
%      frames_input - Anzahl der Bilder der multipage_tif-Datei
%      num_input - Anzahl der Beads, die getrackt werden sollen
%optional input:
%      cutting_range - Anzahl der herausgeschnittenen frames, wenn ein fehlerhafter frame
%                      auftaucht. Wenn also die durch num_input vorgegebenen
%                      Beads nicht gefunden werden, so gehen im Bereich von
%                      [frame - floor(cutting_range/2), frame + floor(cutting_range/2)]
%                      nicht ins tracking ein; preset: cutting_range = 7 
%      diameter      - Diameter of the Beads in Pixel, preset: diameter = 33
%      binning       - Binning of the frames (1 - 4)
%      magni_input   - magnification of the objective (50, 60, 100); preset magni = 60
%
% Zum Tracken werden Routinen der Griergroup verwendet (bpass, pkfind, cntrd, track).
% bpass filtert das einzelne Bild; pkfind gibt die vorl�ufigen Koordinaten der
% gefundenen Beads zur�ck; cntrd berechnet Zentrum der Beads mit subpixel
% Genauigkeit. Daraufhin wird mit track ein Datenfeld tr erzeugt, dessen 
% Inhalt folgende Bedeutung hat:
% Spalte   Bedeutung
%   1      x-Koordinate des jeweiligen Beads
%   2      y-Koordinate des jeweiligen Beads
%   3      frame des jeweiligen Beads
%   4      Numer des Beads
%
%output:
%       n tif-files: F�r n getrackte Beads werden n Graphen gespeichert, die jeweils
%                      frame gegen x- bzw. y-Werte darstellen ohne und mit
%                      Driftkorrektur.
%       txt-file: Enth�lt Koordinaten der Beads, Steigung des Drifts bzw. nach Drift- 
%                 korrektur, Standardabweichung und Federkonstante f�r jeden 
%                 Bead und f�r x-Koordinaten und y-Koordinaten
%
%       Ausgegebene Dateien werden in Ordner der multipage_tif-Datei
%       gespeichert!!
%******************************************************************************************
function [tr, tbl_file] = tracking(frames_input, num_input, cutting_range, diameter, binning, magni_input)

%'nargin' steht f�r 'number of arguments'. Im Folgenden werden bei
%verschiedenener Wahl der Zahl Eingangsparameter die optionalen Argumente, falls
%sie durch Aufrufen der Routine nicht bestimmt werden, vom Programm
%festgelegt.
switch nargin
    case 2
       cutting_range = 7; %muss ungerade sein
       diameter = 33;
       binning = 1; 
       magni_input = 60;
    case 3 
       diameter = 33;
       binning = 1; 
       magni_input = 60;
    case 4
       binning = 1; 
       magni_input = 60;
    case 5 
       magni_input = 60;
    case 6 
        
    otherwise
    fprintf(1, 'Wrong number of arguments!\n 1. Arg.: Number of Frames\n 2. Arg.: Number of Beads\n Optional arguments:\n 3. Arg.: ');
    fprintf(1, 'Range of the cutting, if a frame does not give the right result\n          (must be a odd number)');
    fprintf(1, '; preset: cutting_range = 7\n 4. Arg.: Diameter of the Beads in Pixel (binning = 1; must be odd); preset: diameter = 33\n');
    fprintf(1, ' 5. Arg.: Binning of the frames (1 -4) ; preset: binning = 1\n');  
    fprintf(1, ' 6. Arg.: magnification of the objective (50, 60, 100); preset: magni = 60\n');
    return; 
end    
%'binning' und 'diameter' sind auf bestimmte Bereiche limitiert:
if (binning <= 0) | (binning > 4)
    fprintf(1, 'Binning is out of range (1 - 4)!!\n');
    return;    
end 
if (diameter < 5) | (diameter > 35)
    fprintf(1, 'Diameter of the Beads is out of range (5 - 35)!!\n');
    return;
elseif (diameter/2 == floor(diameter/2))
    diameter = round(diameter/2)*2 + 1;    
    fprintf(1, 'Warning: diameter has to be an odd valued integer.\n    The programm sets diameter = %2.0f\n', diameter);
end
%cutting_range muss ungerade sein
cutting_range = round(cutting_range);
if (cutting_range/2 == floor(cutting_range/2))
    cutting_range = cutting_range + 1;    
    fprintf(1, 'Warning: cutting_range has to be an odd valued integer.\n    The programm sets cutting_range = %2.0f\n', cutting_range);
end
%Berechnung des tats�chlichen Durchmessers der Beads aufgrund von binning
diam_px = round(diameter/binning);
if (diam_px/2 == floor(diam_px/2))
      diam_px = diam_px + 1;
end
%Festlegung von der Bandpass-Grenze:
pass_limit = diam_px + 2;
%�ffnet Dialogfenster zur Eingabe der gew�nschten multipage_tif-Datei
[FileName,PathName] = uigetfile('*.tif');
%Falls auf Abbrechen gedr�ckt wird, soll Funktion tracking verlassen werden
if (FileName == 0) & (PathName == 0);
    return;
end    
%Strings f�r Tif- und txt-Datei:
file_path= [PathName, FileName];
txt_file = [PathName, 'Kalibrierung', '_L', strrep(FileName, '.tif', ''), '.txt'];
tbl_file = [PathName, 'table_L', strrep(FileName, '.tif', ''), '.mat'];
%Festlegung wichtiger Konstanten zur Berechnung der Federkonstanten
switch magni_input
    case 60
        magni = binning*0.03894775777;
    case 100
        magni = binning*0.07756686399;
    case 50
        magni = binning*0.03894; %noch nicht kalibriert!!
    otherwise
        fprintf(1, 'Wrong objective magnification! Please choose 50, 60 or 100.\n');
        return;
end        
k_boltzmann = 1.3806505E-23; %Boltzmannkonstante
temp = 293.15; %Temperatur im Labor

frames = frames_input;
num_beads = num_input;
%count z�hlt die frames die beim tracking aufgrund fehlerhafter frames
%herausgeschnitten werden
count = 0;
%i ist die Laufvariable f�r folgende while-Schleife und markiert
%den ausgewerteten frame
i = 1;
k = 1;
%noise ist ein Parameter der bpass Routine
noise = 1;
pos_list = 0;
pos=1;
l_pos_list = 100;
pos_list_all = [];
%Folgende while-Schleife liest Bilder aus, findet Beads und speichert Daten
%(x-Wert, y-Wert, frame) am Ende aus jedem Bild in ein einziges Array 'pos_list'.
%Zus�tzlich soll, falls die gefundene Anzahl an Beads "num_beads" gr��er 
%(bzw. kleiner) als "num_input" ist, der Bandpass sukzessiv erh�ht
%(bzw. erniedrigt) werden. Jedesmal wird die Routine pkfnd die Anzahl der gefundenen 
%Beads bestimmen. Dadurch wird pass_limit so eingestellt, dass
%num_beads=num_input ist. Bewegt sich pass_limit aus den zugelassen Bereich (1-50), 
%da z.B. der frame fehlerhaft ist (z.B. keine Beads) so wird innerhalb dieser while-Schleife 
%dieser frame und die frames in der Umgebung (insgesamt cutting_range
%frames) aus der pos_list herausgenommen. Zur Kontrolle von pkfnd und cnt
%wird in fig(1) der erste frame mit getrackten Koordinaten ausgegeben. Hier
%kann �berpr�ft werden, ob das Zentrum der Beads gefunden wird. Falls ein
%fehlerhafter frame auftritt, wird dieser auch jedesmal ausgegeben, damit
%sich leichter ein Grund finden l��t.
while(i <= frames_input)  
  %in 'img' wird das erste Bild geladen (s. "help" f�r unterst�tzte Formate und Bildtiefen)  
  img = double(imread(file_path,i));    
  % bpass-Routine
  %    input:
  %    1.Arg.: Geladenen Bild (->2-dim. Array)
  %    2.Arg.: L�nge in Pixeln �ber die Rauschen gemittelt werden soll
  %    3.Arg.: Bandpass-Grenze in Pixeln (ungerader Wert); sollte gr��er als ein typisches Objekt sein 
  %    output:
  %    Gefiltertes Bild (-> 2-dim. array) 
  %Filterung des Bildes
  img_filter = bpass(img, noise, pass_limit);
  %jetzt wird in max_bright h�chste Intensit�t (zw. 0-255) des Bildes
  %img_filter berechnet
  max_bright = max(max(img_filter)); 
  %und daraus berechnet sich der Schwellenwert 'thrh' f�r die Routine pkfnd
  thrh =  max_bright - max_bright/3;
  % pkfnd-Routine:
  %   inputs:
  %   1.Arg.: Das (gefilterte) Bild in dem Helligkeitsspeaks gefunden werden sollen
  %   2.Arg.: Der kleinste Helligkeitswert, der noch als lokales Maximum
  %           druchgehen soll
  %   3.Arg.(optional): Wenn die Daten des Bildes verrauscht sind, d.h. das
  %                     pro Teilchen, das getrackt werden soll, mehrere
  %                     lokale Maxima vorliegen, soll hellster Wert
  %                     genommen werden. Wert sollte etwas gr��er als
  %                     Teilchendurchmesser in Pixeln sein
  %   output:
  %   (Nx2)-array, dass in [:,1] die x-Werte der lokalen Maxima enth�lt und
  %   in [:,2] die zugeh�rigen y-Werte
  pk = pkfnd(img_filter, thrh, pass_limit);
  %Die Routine cntrd berechnet das genaue Zentrum eines jeden gefundenen
  %Beads der Routine pkfnd
  %  cntrd-Routine
  %    inputs:
  %    1.Arg.: Das gefilterte Bild
  %    2.Arg.: output der pkfnd-Routine
  %    3.Arg.: Dieser Wert entspricht der Gr��e der zu verfolgenden Beads in Pixeln
  %            plus 2 und gibt den Bereich an �ber den bei der Kalkulation des
  %            Zentrums eines jeden Beads gemittelt werden soll.
  %    output:
  %    (Nx4)-Array, dass f�r n getrackte Beads x-, y-, Helligkeitswerte und
  %    Radius gespeichert hat
  cnt = cntrd(img_filter, pk, diam_px + 2);
  num_beads = size(cnt,1); %Anzahl der getrackten Beads    
  %Folgende while-Schleife erh�ht pass_limit um 2 solange die Anzahl der
  %gefunden Beads num_beads gr��er als Eingabe num_input ist
  while (num_beads > num_input)
      pass_limit = pass_limit + 2;
      if (pass_limit >= 51)
          fprintf(1, 'bandpass limit is too big (>=51)\n');
          break;
      end    
      img_filter = bpass(img, noise, pass_limit);
      max_bright = max(max(img_filter)); 
      thrh =  max_bright - max_bright/2;
      pk = pkfnd(img_filter, thrh, pass_limit);
      cnt = cntrd(img_filter,pk, diam_px + 2);
      num_beads = size(cnt,1);
  end
  %Folgende while-Schleife erniedrigt pass_limit um 2 solange die Anzahl der
  %gefunden Beads num_beads kleiner als Eingabe num_input ist
  while (num_beads < num_input)
      pass_limit = pass_limit - 2;
      if (pass_limit <= 1)
          fprintf(1, 'bandpass limit is too small (<=0)\n');
          break;
      end    
      img_filter = bpass(img, noise, pass_limit);
      max_bright = max(max(img_filter)); 
      thrh =  max_bright - max_bright/3;
      pk = pkfnd(img_filter, thrh, pass_limit);
      cnt = cntrd(img_filter, pk, diam_px + 2);
      num_beads = size(cnt,1);
  end
  
    fprintf(1, 'frame: %1.0f; threshold: %4.2f; bandpass max.: %4.0f\n', i, thrh, pass_limit);
    fprintf(1, '%4.0f features were found\n', num_beads);
  
  %Falls trotz der vorhergehenden while-Schleifen die Anzahl der getrackten
  %Beads num_beads nicht mit num_input �bereinstimmen, sollen frames um
  %i.ten fehlerhaften frame im Ausma� von cutting_range herausgeschnitten
  %werden
  if (num_beads ~= num_input)
      %Da um den fehlerhaften frame herum geschnitten werden soll, m�ssen
      %zwischen den F�llen i<cutting_range und i>cutting_range
      %unterschieden werden
      if (i >= cutting_range)
          %find_frame stellt 1-dim. array dar, dass die frame-Nummern
          %enth�lt, die herausgeschnitten werden
          find_frame(count + 1:count + cutting_range) = (i-floor(cutting_range/2)):(i+floor(cutting_range/2));
          %Es soll danach erst bei frame i + cutting_range weiter getrackt werden 
          i = i + cutting_range;
      else
          find_frame(1:cutting_range) = 1:cutting_range;
          i = cutting_range + 1;
      end
      frames = frames - cutting_range;%Zahl der tats�chlich verwendeten frames
      count = count + cutting_range;%Zahl der herausgeschnittenen frames    
      pass_limit = diam_px + 2;%pass_limit wird wieder zur�ck auf Ausgangswert gesetzt 
      continue;
  end
  %Erster frame soll immer falls nicht dieser schon fehlerhaft ist
  %ausgegeben werden
  if (i == 1);
      %Bestimmung der Gr��e der Bilder f�r sp�tere 2-dim.
      %Potentialdarstellung
      [m,n] = size(img);
      figure(1),
      colormap('gray'),
      imagesc(img_filter);
      hold on
      plot (cnt(:,1), cnt(:,2), '+r');
      hold off
  end
  
  %speichern der Koordinaten in der Positionsliste pos_list
  for j=1:num_input
     if (mod(pos, l_pos_list) == 0)  
        k = k+1;
     end 
     pos = num_input*(i - count - 1) + j - l_pos_list*(k-1);
     pos_list(pos,1:3,k) = [cnt(j,1:2), i - count];
  end
  i = i + 1;
end  

find_zero = find(pos_list(:,1,k)==0);
%Falls �berhauft keine Ergebnisse erzielt wurden, soll das ausgegeben
%werden:
if (pos_list == 0)
    fprintf(1, 'No results! Check your parameters (e.g. number of beads)!!\n');
    return;
end 

pos_list_all = pos_list(:,:,1);
if (k > 1)
  for j = 2:k;
      pos_list_all = vertcat(pos_list_all, pos_list(:,:,j));
  end
end  
pos_list_all((k-1)*l_pos_list + find_zero(1,1):k*l_pos_list, :) = [];
%   track-Routine
%    input:
%    1.Arg.: die zuvor generierte pos_list
%    2.Arg.: Absch�tzung der maximalen Wegl�nge in Pixel, die ein Bead
%            innerhalb eines Zeitintervalls zur�cklegt
%    output:
%    (frames*Nx4)-array:
%           1. Spalte: x-Werte
%           2. Spalte: y-Werte
%           3. Spalte: frame
%           4. Spalte: Bead
tr = track(pos_list_all, 2*diam_px);
tr = vertcat(tr, [m, n, 0, 0]); 
if (frames < frames_input)
   fprintf(1, 'Only %4.0f frames were used\n', frames);
   fprintf(1, 'The following frames had to be deleted:\n');
   disp(find_frame);
else
   fprintf(1, 'Congratulation, all frames were used!\n');
end

%frame ist 1-dim. Feld und dient sp�ter beim plotting zur Zuordnung
frame = 0 : (frames - 1);
%Erzeugung und �ffnen des txt-Files 
fid = fopen(txt_file,'w'); 
%�berschrift der txt-Datei:
fprintf(fid, 'Kalibrierung bei binning %1.0f und %4.0f frames\n\n\n', binning, frames);
fprintf(fid, 'Durchmesser der Beads ist: %3.2f�m\n', diam_px*magni);
%Es sollen sp�ter die Datenpunkte der Beadzentren in Polarkoordianten
%ausgedr�ckt werden. Daraufhin soll f�r einen bestimmten Winkelbereich
%die msd bzw. die Federkonstante bestimmt werden. angle_step ist der Winkelbereich 
%in Grad und angle_steps gibt die Anzahl der ben�tigten Schritte f�r einen 
%kompletten Umlauf an 
angle_step = 30;
angle_steps = 360/angle_step;
%msd_angle_corr(:,:) bzw. stiffness_angle(:,:) enth�lt die msd bzw. die Federkonstante
%f�r jeden Winkelbereich und jeden Bead  
msd_angle_corr(1:angle_steps,1:num_input) = 0;
stiffness_angle(1:angle_steps,1:num_input) = 0;

%Erste for-Schleife geht von 1 bis Anzahl der Beads; in zweiter Schleife steht j=0 f�r Kalibrierung
%f�r x-Werte und j=2 f�r Kalibrierung der y-Werte
for i=1:num_input;
 for j=1:2;
      %data ist ein 1-dim. array das die x-Werte (j=1) bzw. die y-Werte (j=2)
      %des jeweiligen i.-ten Beads enth�lt 
      data =  magni*tr(frames*(i-1)+1:frames*i,j)';
      %Driftkorrektur �ber lineare Regression der Werte
      [lin_fit,errors1] = polyfit(frame, data, 1);
      %slope(j) enth�lt die jeweilige Steigung
      slope(j) = lin_fit(1);
      %corr enth�lt die Werte aus data nach Driftkorrektur
      corr = data - slope(j)*frame;
      %Zur �berpr�fung der Driftkorrektur wird Steigung der lin. Regression
      %von corr bestimmt und sp�ter in txt-File ausgegeben
      [lin_fit_corr, errors2] = polyfit(frame, corr, 1);
      slope_corr(j) = lin_fit_corr(1);
      %mean_xy bestimmt jetzt den genauen Mittelpunkt der Fallen nach
      %Driftkorrektur und data_corr enth�lt f�r Berechnung der Abst�nde r
      %in Polarkoordinaten bzw. f�r sp�tere Ermittlung der msd bzw.
      %Federkonstanten die relevanten Daten
      mean_xy(i,j) = mean(corr');
      data_corr(1:frames,j,i) = corr' - mean_xy(i,j);  
      %num ist Nummer des Ausgabefensters f�r plotting und wird auf frames
      %+ 1 gesetzt damit es keine doppelte Belegung mit Ausgabe der fehlerhaften 
      % frames gibt
      num = frames + i;
      %Es wird f�r jeden getrackten Bead ein Fenster ge�ffnet, dass jeweils
      %vier Graphiken enth�lt: x-Werte gegen frames ohne und mit Driftkorrektur 
      %und y-Werte ohne und mit Driftkorrektur 
      if (j == 1)
         figure(num), subplot(2,2,1), plot( frame, data,'+r'), xlabel('frames'), ylabel('x-Werte [�m]'), ...
         title(['Bead ',int2str(i),': x-Werte ohne Driftkorrektur']), grid on, grid minor;
         hold on
         plot(frame, lin_fit(2) + lin_fit(1)*frame, '-k')
         hold off
         figure(num), subplot(2,2,2), plot(frame, corr, '*r'),xlabel('frames'), ylabel('x-Werte[�m]'), ...
         title(['Bead ',int2str(i),': x-Werte mit Driftkorrektur']), grid on, grid minor;
         hold on
         plot(frame, lin_fit_corr(2) + lin_fit_corr(1)*frame, '-k')
         hold off
      end
      if (j == 2)
         figure(num), subplot(2,2,3), plot(frame, data, '+r'), xlabel('frames'), ylabel('y-Werte[�m]'), ...
         title(['Bead ',int2str(i),': y-Werte ohne Driftkorrektur']), grid on, grid minor;
         hold on
         plot(frame, lin_fit(2) + lin_fit(1)*frame, '-k')
         hold off
         figure(num), subplot(2,2,4), plot(frame, corr, '*r'), xlabel('frames'), ylabel('y-Werte[�m]'), ...
         title(['Bead ',int2str(i),': y-Werte mit Driftkorrektur']), grid on, grid minor;
         hold on
         plot(frame, lin_fit_corr(2) + lin_fit_corr(1)*frame, '-k')
         hold off
         %diese Graphiken werden zudem im Ordner in dem sich auch der Film
         %befindet gespeichert.
         saveas(num, [PathName, 'calib_Bead', int2str(i), '_L', FileName], 'tif')
      end
   end   
 %data_corr(1:frames,3) enth�lt den Betrag r und data_corr(1:frames,4)
 %den Winkel phi f�r Polarkoordianten: x = r*cos(phi), y=r*sin(phi).
 data_corr(1:frames,3,i) = sqrt(data_corr(1:frames,1,i).^2 + data_corr(1:frames,2,i).^2);
 for k=1:frames
     if (data_corr(k,1,i)>0 & data_corr(k,2,i)>0)
         data_corr(k,4,i) = atand(data_corr(k,2,i)./data_corr(k,1,i));
     elseif (data_corr(k,1,i)<0 & data_corr(k,2,i)>0)    
         data_corr(k,4,i) = -atand(data_corr(k,2,i)./data_corr(k,1,i)) + 90;
     elseif (data_corr(k,1,i)<0 & data_corr(k,2,i)<0)
         data_corr(k,4,i) = atand(data_corr(k,2,i)./data_corr(k,1,i)) + 180;
     else
         data_corr(k,4,i) = atand(data_corr(k,2,i)./data_corr(k,1,i)) + 360;
     end    
 end
 %Bestimmung der msd_angle_corr (hier in m^2) und der Federkonstanden
 %innerhalb des definierten Winkelbereiches
 for j=1:angle_steps;
    indices = find((data_corr(1:frames,4,i) > angle_step*(j-1)) & (data_corr(1:frames,4,i) <= angle_step*j));
    sz_indices = size(indices);
    frames_angle(j) = sz_indices(1);
    if (frames_angle(j) ~= 0)
        for k=1:frames_angle(j);
            msd_angle_data(k) = data_corr(indices(k), 3, i);
        end    
     msd_angle = (1.0E-6)^2*mean(msd_angle_data.^2);
     %Korrektur der msd_angle aufgrund der Instabilit�t des Laserfokus mit einer Standardabweichung von 8nm
     msd_angle_corr(j) = msd_angle - (8E-9)^2;
     %Berechnung der Federkonstanten   
     stiffness_angle(j,i) = k_boltzmann*temp/msd_angle_corr(j);   
     msd_angle_data = [];
    end
 end  
 for k = 1:3;
    %Berechnung der msd aus den x- bzw.  y-Werten und den Abst�nden r: 
    msd = (1.0E-6)^2*mean(data_corr(1:frames,k,i).^2);
    msd_corr(k) = msd - (8E-9)^2;
    stiffness(k) = k_boltzmann*temp/msd_corr(k);   
 end      
 % Schreiben der Daten der Kalibrierung in txt.-File
 fprintf(fid, '\nBead %1.0f (%4.2f�m/%4.2f�m):\n', i, mean_xy(i,1), mean_xy(i,2));
 fprintf(fid, 'Steigung des Drifts in x-Richtung: %+1.10f�m/frame\n', slope(1));
 fprintf(fid, 'Steigung des Drifts in y-Richtung: %+1.10f�m/frame\n', slope(2));
 fprintf(fid, 'Steigung der korrigierten x-Werte: %+1.10f�m/frame\n',slope_corr(1));
 fprintf(fid, 'Steigung der korrigierten y-Werte: %+1.10f�m/frame\n\n', slope_corr(2));
 fprintf(fid, 'Standardabweichung f�r x-Werte: %3.4fnm\n', (1.0E9)*sqrt(msd_corr(1)));
 fprintf(fid, 'Federkonstante kappa f�r x-Werte: %2.4fpN/�m\n', (1.0E6)*stiffness(1));
 fprintf(fid, 'Standardabweichung sigma f�r y-Werte: %2.4fnm\n', (1.0E9)*sqrt(msd_corr(2)));
 fprintf(fid, 'Federkonstante kappa f�r y-Werte: %2.4fpN/�m\n\n', (1.0E6)*stiffness(2));
 fprintf(fid, 'Standardabweichung f�r Abstand r: %3.4fnm\n', (1.0E9)*sqrt(msd_corr(3)));
 fprintf(fid, 'Federkonstante kappa: %2.4fpN/�m\n\n', 2*(1.0E6)*stiffness(3));
 fprintf(fid, 'Frames pro Winkelbereich bei Gleichverteilung: %4.2f\n\n', frames/angle_steps);
 fprintf(fid, 'phi[Grad]    frames        StD[nm]    kappa[pN/�m]\n');
 for j=1:angle_steps;
     fprintf(fid, '%3.0f-%3.0f    %4.0f(%+2.1f%%)      %3.4f      %2.4f\n', (j-1)*angle_step, j*angle_step, ...
         frames_angle(j), 100*(frames_angle(j)/(frames/angle_steps)-1), (1.0E9)*sqrt(msd_angle_corr(j)), ...
         2*(1.0E6)*stiffness_angle(j,i));
 end
end
fclose(fid);

for i=1:num_input;
    t = 0:diam_px*magni/200:2*diam_px*magni;
    for j=1:angle_steps;
          figure(2*frames), plot3(t*cosd(angle_step*(j-0.5)) + mean_xy(i,1), ...
                t*sind(angle_step*(j-0.5)) + mean_xy(i,2), (1.0E6)*stiffness_angle(j,i)*t.^2, '-k', 'LineWidth', 2), ...
                zlim([0. 3.]), xlabel('distance in x-direction [�m]'), ylabel('distance in y-direction [�m]'), ...
                zlabel('Pot. Energy [pN*�m]'), title('Potential energy of the optical tweezer'), ...
                grid on, grid minor;
          hold on
    end
    for k=1:10
        z(1:angle_steps + 1) = 5/10*k; 
      for j=1:angle_steps;
        x_plot_data(j) = sqrt(z(1)/((1.0E6)*stiffness_angle(j,i)))*cosd(angle_step*(j-0.5)) + mean_xy(i,1);
        y_plot_data(j) = sqrt(z(1)/((1.0E6)*stiffness_angle(j,i)))*sind(angle_step*(j-0.5)) + mean_xy(i,2);
      end  
      x_plot_data(angle_steps + 1) = sqrt(z(1)/((1.0E6)*stiffness_angle(1,i)))*cosd(angle_step*0.5) + mean_xy(i,1);
      y_plot_data(angle_steps + 1) = sqrt(z(1)/((1.0E6)*stiffness_angle(1,i)))*sind(angle_step*0.5) + mean_xy(i,2);
      plot3(x_plot_data, y_plot_data, z, '-r', 'LineWidth', 2);
      hold on
    end  
end
hold off
saveas(2*frames, [PathName, 'potential_angle_L', FileName], 'tif');
%Ausgabe der 2-dim. Verteilung der Beadzentren und Ausgabe der Potentiale der
%optischen Fallen:

%bin ist Vergr��erungsfaktor, d.h. es stehen zur Bestimmung der subpixel
%genauen Beadzentren "bin" mal so viele Pixel zu Verf�gung
bin = 12;
%distr ist ein 2-dim. (bin*m,bin*n)-array, dass sp�ter graphisch dargestellt werden soll, wobei jedes Element des
%arrays f�r einen Pixel steht und diese Elemente zuert auf Null gesetzt
%werden. Sp�ter werden die Beadzentren gez�hlt, die in ein solchen
%Pixelfeld fallen.
distr(1:bin*m,1:bin*n) = 0;
for i=1:num_input;
  %Folgende Schleife geht alle frames durch, betrachtet jeden x- bzw. y-Wert und bestimmt mit dem floor-Befehl
  %die jeweiligen Indizes f�r das distr-Feld
  for k=1:frames;
      find_bm = floor(bin/magni*(data_corr(k,2,i) + mean_xy(i,2))) + 1;
      find_bn = floor(bin/magni*(data_corr(k,1,i) + mean_xy(i,1))) + 1;
      distr(find_bm, find_bn) = distr(find_bm, find_bn) + 1;
  end
end
%potential ist proportional zum wahren Potential U(x)=-k_b*T*exp(P(x)), wobei P(x) die Wahrschinlichkeit darstellt
%den Bead am Ort x anzutreffen. Einheit: pN*�m
potential = -(1.0E18)*k_boltzmann*temp*log((distr + 1)/frames);
%Folgende for-Schleife ist f�r die Ausgabe zust�ndig.
for i=1:num_input;
  %Folgende vier Zeilen sind zur Bestimmung der Ausgabebereiche wichtig. Es wird f�r jeden Bead vom Mittelwert mean_corr_xy
  %ausgegangen und der Bereich um den Mittelwert mit 3fachen Beaddurchmesser berechnet    
  sz_min_m = round(bin*mean_xy(i,2)/magni - 1.5*diam_px);
  sz_max_m = round(bin*mean_xy(i,2)/magni + 1.5*diam_px);
  sz_min_n = round(bin*mean_xy(i,1)/magni - 1.5*diam_px);
  sz_max_n = round(bin*mean_xy(i,1)/magni + 1.5*diam_px);
  x_i = magni/bin*(1:(sz_max_m - sz_min_m + 1));
  y_i = magni/bin*(1:(sz_max_n - sz_min_n + 1));

  %Ausgabe der 2-dim. Verteilung f�r i-ten Bead
  figure(num+i), colormap(jet), 
  imagesc(distr(sz_min_m:sz_max_m, sz_min_n:sz_max_n)), colorbar;
  %Speicherung der 2-dim. Verteilung f�r i-ten Bead
  saveas(num + i, [PathName, 'distribution_bead', int2str(i), '_L', FileName], 'tif');
  %Ausgabe des 3-dim. Fallenpotentials
  figure(num + num_input + i),
  meshc(x_i, y_i, potential(sz_min_m:sz_max_m, sz_min_n:sz_max_n)), zlabel('Potential Energy [pN*�m]') %
  shading interp
  colormap(jet), colorbar, axis on;
  %Speicherung des 3-dim. Fallenpotentials f�r i-te Falle
  saveas(num + num_input + i, [PathName, 'potential_bead', int2str(i),'_L', FileName], 'tif');
end
end
